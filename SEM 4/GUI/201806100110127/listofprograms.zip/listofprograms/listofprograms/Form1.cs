﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace listofprograms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
            
        private void button1_Click(object sender, EventArgs e)
        {
            string value = "";
            
            
            if (checkBox1.CheckState == CheckState.Checked)
            {
                value += checkBox1.Text;
            }
            if (checkBox2.CheckState == CheckState.Checked)
            {
                value += checkBox2.Text;
            }
            if (checkBox3.CheckState == CheckState.Checked)
            {
                value += checkBox3.Text;
            }
            if (checkBox4.CheckState == CheckState.Checked)
            {
                value += checkBox4.Text;
            }
            if (checkBox5.CheckState == CheckState.Checked)
            {
                value += checkBox5.Text;
            }
            if (checkBox6.CheckState == CheckState.Checked)
            {
                value += checkBox6.Text;
            }
            if (checkBox7.CheckState == CheckState.Checked)
            {
                value += checkBox7.Text;
            }
            if (checkBox8.CheckState == CheckState.Checked)
            {
                value += checkBox8.Text;
            }
            label1.Text = value ;
           
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
         
        }
    }
}
