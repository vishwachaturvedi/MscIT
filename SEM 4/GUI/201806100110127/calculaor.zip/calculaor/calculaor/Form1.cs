﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculaor
{
    public partial class CALCULATOR : Form
    {
        string input = string.Empty;
        string operand1 = string.Empty;
        string operand2 = string.Empty;
        char operations;
        double result = 0.0;

        public CALCULATOR()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.textbox.Text = "";
            input += "7";
            this.textbox.Text += input;
        }

        private void button18_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            this.textbox.Text = "";
            this.input = string.Empty;
            this.operand1 = string.Empty;
            this.operand2 = string.Empty;
        }

        private void eight_Click(object sender, EventArgs e)
        {
            this.textbox.Text = "";
            input += "8";
            this.textbox.Text += input;
        }

        private void four_Click(object sender, EventArgs e)
        {
            this.textbox.Text = "";
            input += "4";
            this.textbox.Text += input;
        }

        private void five_Click(object sender, EventArgs e)
        {
            this.textbox.Text = "";
            input += "5";
            this.textbox.Text += input;
        }

        private void six_Click(object sender, EventArgs e)
        {
            this.textbox.Text = "";
            input += "6";
            this.textbox.Text += input;
        }

        private void one_Click(object sender, EventArgs e)
        {
            this.textbox.Text = "";
            input += "1";
            this.textbox.Text += input;
        }

        private void two_Click(object sender, EventArgs e)
        {
            this.textbox.Text = "";
            input += "2";
            this.textbox.Text += input;
        }

        private void three_Click(object sender, EventArgs e)
        {
            this.textbox.Text = "";
            input += "3";
            this.textbox.Text += input;
        }

        private void dot_Click(object sender, EventArgs e)
        {
            input += ".";
        }

        private void zero_Click(object sender, EventArgs e)
        {
            this.textbox.Text = "";
            input += "0";
            this.textbox.Text += input;
        }

        private void equals_Click(object sender, EventArgs e)
        {
            operand2 = input;
            double num1, num2;
            double.TryParse(operand1, out num1);
            double.TryParse(operand2, out num2);

            if (operations == '+')
            {
                result = num1 + num2;
                textbox.Text = result.ToString();
            }
            else if (operations == '-')
            {
                result = num1 - num2;
                textbox.Text = result.ToString();
            }
            else if (operations == '*')
            {
                result = num1 * num2;
                textbox.Text = result.ToString();
            }
            else if (operations == '/')
            {
                if (num2 != 0)
                {
                    result = num1 / num2;
                    textbox.Text = result.ToString();
                }
                else
                {
                    textbox.Text = "DIV/Zero!";
                }

            }
        }

        private void plus_Click(object sender, EventArgs e)
        {
            operand1 = input;
            operations = '+';
            input = string.Empty;

        }

        private void minus_Click(object sender, EventArgs e)
        {
            operand1 = input;
            operations = '-';
            input = string.Empty;

        }

        private void div_Click(object sender, EventArgs e)
        {
            operand1 = input;
            operations = '/';
            input = string.Empty;

        }

        private void mul_Click(object sender, EventArgs e)
        {
            operand1 = input;
            operations = '*';
            input = string.Empty;

        }

        private void nine_Click(object sender, EventArgs e)
        {
            this.textbox.Text = "";
            input += "9";
            this.textbox.Text += input;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
