﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace stop_watch
{
    public partial class STOPWATCH : Form
    {
        int TH, TM, TS;


        public STOPWATCH()
        {
            InitializeComponent();
            TH = TM = TS = 00;
        }

       
        
           
       

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            TH = TM = TS = 00;
            S.Text = ap(TS);
            M.Text = ap(TM);
            H.Text = ap(TH);

        }
        private string ap(double str)
        {
            if (str <= 9)
            {
                return "0" + str;
            }
            else
                return str.ToString();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            TS++;
            if (TS > 59)
            {
                TM++;
                TS = 00;
            }
            if (TM > 59)
            {
                TH++;
                TM = 00;
            }
            if (TH > 12)
            {
                PA.Text = "AM";
            }

            S.Text = ap(TS);
            M.Text = ap(TM);
            H.Text = ap(TH);
        }
    }
}
