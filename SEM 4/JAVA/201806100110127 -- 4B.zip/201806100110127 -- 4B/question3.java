import java.util.*;

class daydate
{
	Stirng today_date ;
	Stirng nxtweek_date ;


	Scanner sc = new Scanner(System.in);
	System.out.println(" enter date in formal format(mm-dd-yyyy) :");
	today_date = sc.nextline();
	

    switch (month)
        {
            
            case "january" :
		
		 if (day > 31)
                    {
                        System.exit(0);
                    }       
                    if (day + 7 > 31)
                    {
                            new_month = new String("february");
                    }       
                 
                   
                    
	}

        System.out.println("Today's date is "  month,day, year);
        System.out.println("Today's day is "+day);
        System.out.println("Next Week's day is "+ day);
        System.out.println("Next Week's date is "+ nxtweek_date);


}