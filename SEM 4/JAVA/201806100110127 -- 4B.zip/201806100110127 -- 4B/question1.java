import java.util.*;

class monthname
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		
		String month;
		System.out.print("Enter the month name : ");
		month=sc.nextLine();
		
			if(month.equals("january"))
			{
				System.out.println("You have entered January"); 
				System.out.println("Its abbreviation is JAN");
				System.out.println("This is month number 1");
				System.out.println("It has 31 days");
			}
			else if(month.equals("february"))
			{
				System.out.println("You have entered February"); 
				System.out.println("Its abbreviation is FEB");
				System.out.println("This is month number 2");
				System.out.println("It has 28 days");
			}
			else if(month.equals("march"))
			{
				System.out.println("You have entered March"); 
				System.out.println("Its abbreviation is MAR");
				System.out.println("This is month number 3");
				System.out.println("It has 31 days");
			}
			else if(month.equals("april"))
			{
				System.out.println("You have entered April"); 
				System.out.println("Its abbreviation is APR");
				System.out.println("This is month number 4");
				System.out.println("It has 30 days");
			}
			else if(month.equals("may"))
			{
				System.out.println("You have entered May"); 
				System.out.println("Its abbreviation is MAY");
				System.out.println("This is month number 5");
				System.out.println("It has 31 days");
			}
			else if(month.equals("june"))
			{
				System.out.println("You have entered June"); 
				System.out.println("Its abbreviation is JUN");
				System.out.println("This is month number 6");
				System.out.println("It has 30 days");
			}
			else if(month.equals("july"))
			{
				System.out.println("You have entered July"); 
				System.out.println("Its abbreviation is JUL");
				System.out.println("This is month number 7");
				System.out.println("It has 31 days");
			}
			else if(month.equals("august"))
			{
				System.out.println("You have entered August"); 
				System.out.println("Its abbreviation is AUG");
				System.out.println("This is month number 8");
				System.out.println("It has 31 days");
			}
			else if(month.equals("september"))
			{
				System.out.println("You have entered September"); 
				System.out.println("Its abbreviation is SEP");
				System.out.println("This is month number 9");
				System.out.println("It has 30 days");
			}
			else if(month.equals("october"))
			{
				System.out.println("You have entered October"); 
				System.out.println("Its abbreviation is OCT");
				System.out.println("This is month number 10");
				System.out.println("It has 31 days");
			}
			else if(month.equals("november"))
			{
				System.out.println("You have entered November"); 
				System.out.println("Its abbreviation is NOV");
				System.out.println("This is month number 11");
				System.out.println("It has 30 days");
			}
			else if(month.equals("december"))
			{
				System.out.println("You have entered December"); 
				System.out.println("Its abbreviation is DEC");
				System.out.println("This is month number 12");
				System.out.println("It has 31 days");
			}
	}	
}