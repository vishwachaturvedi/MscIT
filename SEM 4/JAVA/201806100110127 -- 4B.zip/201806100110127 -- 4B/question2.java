import java.util.*;

class amrut_saree
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		
		String color;
		
		System.out.print("Enter The Input : ");
		color=sc.nextLine();
		
		int green=0, red=0, blue=0, white=0, other=0 ;

   
			for (int i = 0; i < color.length(); i++)
		{ 
			if (color.charAt(i) == 'r')
              		  {
                  		  red++;
             		  }
              		else if (color.charAt(i) == 'w')
               		 {
                  		  white++;
               		 }
             		else if (color.charAt(i) == 'g')
                	 {
                  		  green++;
               		 }
             	        else if (color.charAt(i) == 'b')
              	 	 {
                 		  blue++;
               		 }
               		 else
              	       	  {
                   		 other++;
                	  }
	       } 
				System.out.println("No. Of Green Sarees : "+g);
				System.out.println("No. Of Red Sarees : "+r);
				System.out.println("No. Of White Sarees : "+w);	
				System.out.println("No. Of Blue Sarees : "+b);
				System.out.println("No. Of Other Sarees : "+o);
	}
}