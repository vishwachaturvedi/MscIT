dict1={'A':1,'B':2,'C':3}
key=input("Enter Key:");

print(dict1[key]);
