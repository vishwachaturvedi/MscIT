
'''
Write a program for merging two dictionaries into one dictionary.
'''

dict1={'A':1,'B':2}
dict2={'C':3}
dict1.update(dict2)
print("Merge dictionary is:",dict1)