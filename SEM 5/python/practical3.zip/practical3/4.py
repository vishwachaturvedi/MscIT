'''
* 
*** 
***** 
******* 
*********
'''
n=5
k=1
for rows in range(1,n+1):
    for cols in range(1,k+1):
        print("*",end="")
    k=k+2;
    print(" ")
