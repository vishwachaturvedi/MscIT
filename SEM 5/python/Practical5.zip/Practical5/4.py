#Write a Python program to convert a list to a tuple.

# Driver function 
l= [1,12,6,45,14] 
print(l)
print(type(l))

t1=tuple(l)
print(t1)
print(type(t1))
