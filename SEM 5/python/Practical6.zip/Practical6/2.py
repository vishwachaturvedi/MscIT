set1={10,20,30}
set2={20,25,40}

print(set1.intersection(set2));
