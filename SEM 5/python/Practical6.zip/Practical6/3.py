set1={10,20,30,40}
set2={10,25,45,30}

print(set1.union(set2));
