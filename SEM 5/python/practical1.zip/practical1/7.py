width = float(input('Please Enter the Width of a Rectangle: '))
height = float(input('Please Enter the Height of a Rectangle: '))
Area = width * height
print("\n Area of a Rectangle is: %.2f" %Area)
