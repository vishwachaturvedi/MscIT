a=int(input("enter 1st number: "))
b=int(input("enter 2nd number: "))
c=a + b
print("sum: ",c)
