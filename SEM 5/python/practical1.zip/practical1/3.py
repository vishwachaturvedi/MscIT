a=int(input("enter 1st number: "))
b=int(input("enter 2nd number: "))
avg = (a+b)/2
print("average: ",avg)
