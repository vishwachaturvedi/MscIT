P = 1000
R = 1
T = 2
SI = (P * R * T) / 100
print("simple interest is", SI)
